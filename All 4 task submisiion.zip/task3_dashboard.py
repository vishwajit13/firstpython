
# CODTECH Internship - Task 3: Interactive Dashboard (Dash)
# This is a simple Plotly Dash app that visualizes the synthetic dataset created in Task 1.
# To run: pip install dash pandas plotly && python task3_dashboard.py
import pandas as pd
from dash import Dash, dcc, html
import plotly.express as px

csv_path = '/mnt/data/task1_synthetic_large.csv'
df = pd.read_csv(csv_path)
df['timestamp'] = pd.to_datetime(df['timestamp'])
daily = df.set_index('timestamp').resample('D').value.mean().reset_index()

app = Dash(__name__)
fig = px.line(daily, x='timestamp', y='value', title='Daily Mean Value')

app.layout = html.Div([
    html.H2('Task 3 — Interactive Dashboard (Dash)'), 
    dcc.Graph(figure=fig),
    html.P('Category counts:'),
    dcc.Graph(figure=px.bar(df['category'].value_counts().reset_index().rename(columns={'index':'category','category':'count'}), x='category', y='count'))
])

if __name__ == '__main__':
    app.run_server(debug=True, port=8050, host='0.0.0.0')
